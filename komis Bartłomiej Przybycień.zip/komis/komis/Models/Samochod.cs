﻿using System.Collections.Generic;

namespace komis.Models
{
    public class Samochod
    {
        public Samochod()
        {
            KlientSamochody = new List<KlientSamochod>();
        }

        public int Id { get; set; }
        public string Marka { get; set; } // dopuszczająca null
        public string Model { get; set; } // dopuszczająca null
        public int RokProdukcji { get; set; }
        public decimal CenaWypozyczenia { get; set; }
        public string Status { get; set; } // dopuszczająca null

        public List<KlientSamochod> KlientSamochody { get; set; }
    }
}
