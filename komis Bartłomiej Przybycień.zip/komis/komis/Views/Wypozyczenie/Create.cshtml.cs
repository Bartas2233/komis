using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace komis.Views.Wypozyczenie
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
