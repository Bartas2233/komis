﻿using System.Collections.Generic;

namespace komis.Models
{
    public class Klient
    {
        public Klient()
        {
            KlientSamochody = new List<KlientSamochod>();
        }

        public int Id { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public string Email { get; set; }
        public string NumerTelefonu { get; set; }

        public List<KlientSamochod> KlientSamochody { get; set; }
    }
}
