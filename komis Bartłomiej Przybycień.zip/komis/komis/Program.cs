﻿using Microsoft.EntityFrameworkCore;
using komis.Data; // Upewnij się, że ta przestrzeń nazw odpowiada lokalizacji klasy KomisContext

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();  // Zmienione z AddRazorPages na AddControllersWithViews

// Dodanie KomisContext do kontenera usług z użyciem ciągu połączenia z appsettings.json
builder.Services.AddDbContext<KomisContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("YourConnectionStringName")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}

app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Dodane mapowanie trasy kontrolera
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
