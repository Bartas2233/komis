﻿using komis.Models;
using Microsoft.AspNetCore.Mvc;
using komis.Data; // Załóżmy, że to przestrzeń nazw Twojego kontekstu bazy danych
using System.Linq;

namespace komis.Controllers
{
    public class SamochodController : Controller
    {
        private readonly KomisContext _context; // Kontekst bazy danych

        public SamochodController(KomisContext context)
        {
            _context = context;
        }

        // GET: Samochod
        public ActionResult Index()
        {
            var samochody = _context.Samochody.ToList();
            return View(samochody);
        }

        // GET: Samochod/Details/5
        public ActionResult Details(int id)
        {
            var samochod = _context.Samochody.FirstOrDefault(s => s.Id == id);
            if (samochod == null)
            {
                return NotFound();
            }
            return View(samochod);
        }

        // GET: Samochod/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Samochod/Create
        [HttpPost]
        public ActionResult Create(Samochod samochod)
        {
            if (ModelState.IsValid)
            {
                _context.Samochody.Add(samochod);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(samochod);
        }

        // GET: Samochod/Edit/5
        public ActionResult Edit(int id)
        {
            var samochod = _context.Samochody.FirstOrDefault(s => s.Id == id);
            if (samochod == null)
            {
                return NotFound();
            }
            return View(samochod);
        }

        // POST: Samochod/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Samochod samochod)
        {
            if (id != samochod.Id)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                _context.Update(samochod);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(samochod);
        }

        // GET: Samochod/Delete/5
        public ActionResult Delete(int id)
        {
            var samochod = _context.Samochody.FirstOrDefault(s => s.Id == id);
            if (samochod == null)
            {
                return NotFound();
            }
            return View(samochod);
        }

        // POST: Samochod/Delete/5
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            var samochod = _context.Samochody.Find(id);
            if (samochod != null)
            {
                _context.Samochody.Remove(samochod);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
