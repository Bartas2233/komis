﻿using Microsoft.EntityFrameworkCore;
using komis.Models;

namespace komis.Data
{
    public class KomisContext : DbContext
    {
        public KomisContext(DbContextOptions<KomisContext> options)
            : base(options)
        {
        }

        public DbSet<Klient> Klienci { get; set; }
        public DbSet<Samochod> Samochody { get; set; }
        public DbSet<Wypozyczenie> Wypozyczenia { get; set; }
        public DbSet<KlientSamochod> KlientSamochody { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<KlientSamochod>()
                .HasKey(ks => new { ks.KlientId, ks.SamochodId });

            modelBuilder.Entity<KlientSamochod>()
                .HasOne(ks => ks.Klient)
                .WithMany(k => k.KlientSamochody)
                .HasForeignKey(ks => ks.KlientId);

            modelBuilder.Entity<KlientSamochod>()
                .HasOne(ks => ks.Samochod)
                .WithMany(s => s.KlientSamochody)
                .HasForeignKey(ks => ks.SamochodId);
        }
    }
}
