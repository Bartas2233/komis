﻿namespace komis.Models
{
    public class KlientSamochod
    {
        public int KlientId { get; set; }
        public Klient Klient { get; set; }

        public int SamochodId { get; set; }
        public Samochod Samochod { get; set; }
    }
}
