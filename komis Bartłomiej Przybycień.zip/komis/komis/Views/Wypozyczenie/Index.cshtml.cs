using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace komis.Views.Wypozyczenie
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
