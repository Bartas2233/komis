﻿namespace komis.Models
{
    public class Wypozyczenie
    {
        public int Id { get; set; }
        public int SamochodId { get; set; }
        public int KlientId { get; set; }
        public DateTime DataRozpoczecia { get; set; }
        public DateTime DataZakonczenia { get; set; }
        public decimal KosztCalkowity { get; set; }

        
        public Samochod? Samochod { get; set; }
        public Klient? Klient { get; set; }
    }
}
