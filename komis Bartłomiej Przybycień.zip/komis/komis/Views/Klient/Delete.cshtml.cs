using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace komis.Views.Klient
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
