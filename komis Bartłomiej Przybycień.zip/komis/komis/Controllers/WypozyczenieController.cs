﻿using komis.Models;
using komis.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;
using System.Threading.Tasks;

namespace komis.Controllers
{
    public class WypozyczenieController : Controller
    {
        private readonly KomisContext _context;

        public WypozyczenieController(KomisContext context)
        {
            _context = context;
        }

        // GET: Wypozyczenie
        public async Task<IActionResult> Index()
        {
            var wypozyczenia = await _context.Wypozyczenia
                .Include(w => w.Klient)
                .Include(w => w.Samochod)
                .ToListAsync();
            return View(wypozyczenia);
        }

        // GET: Wypozyczenie/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var wypozyczenie = await _context.Wypozyczenia
                .Include(w => w.Klient)
                .Include(w => w.Samochod)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (wypozyczenie == null)
            {
                return NotFound();
            }
            return View(wypozyczenie);
        }

        // GET: Wypozyczenie/Create
        public IActionResult Create()
        {
            ViewData["KlientId"] = new SelectList(_context.Klienci, "Id", "Nazwisko");
            ViewData["SamochodId"] = new SelectList(_context.Samochody, "Id", "Marka");
            return View();
        }

        // POST: Wypozyczenie/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("SamochodId,KlientId,DataRozpoczecia,DataZakonczenia,KosztCalkowity")] Wypozyczenie wypozyczenie)
        {
            if (ModelState.IsValid)
            {
                _context.Add(wypozyczenie);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["KlientId"] = new SelectList(_context.Klienci, "Id", "Nazwisko", wypozyczenie.KlientId);
            ViewData["SamochodId"] = new SelectList(_context.Samochody, "Id", "Marka", wypozyczenie.SamochodId);
            return View(wypozyczenie);
        }

        // GET: Wypozyczenie/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var wypozyczenie = await _context.Wypozyczenia.FindAsync(id);
            if (wypozyczenie == null)
            {
                return NotFound();
            }

            ViewData["KlientId"] = new SelectList(_context.Klienci, "Id", "Nazwisko", wypozyczenie.KlientId);
            ViewData["SamochodId"] = new SelectList(_context.Samochody, "Id", "Marka", wypozyczenie.SamochodId);
            return View(wypozyczenie);
        }

        // POST: Wypozyczenie/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,SamochodId,KlientId,DataRozpoczecia,DataZakonczenia,KosztCalkowity")] Wypozyczenie wypozyczenie)
        {
            if (id != wypozyczenie.Id)
            {
                return NotFound();
            }

            bool samochodExists = await _context.Samochody.AnyAsync(s => s.Id == wypozyczenie.SamochodId);
            if (!samochodExists)
            {
                ModelState.AddModelError("SamochodId", "Wybrany samochód nie istnieje.");
                ViewData["KlientId"] = new SelectList(_context.Klienci, "Id", "Nazwisko", wypozyczenie.KlientId);
                ViewData["SamochodId"] = new SelectList(_context.Samochody, "Id", "Marka", wypozyczenie.SamochodId);
                return View(wypozyczenie);
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(wypozyczenie);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Wypozyczenia.Any(e => e.Id == wypozyczenie.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["KlientId"] = new SelectList(_context.Klienci, "Id", "Nazwisko", wypozyczenie.KlientId);
            ViewData["SamochodId"] = new SelectList(_context.Samochody, "Id", "Marka", wypozyczenie.SamochodId);
            return View(wypozyczenie);
        }

        // GET: Wypozyczenie/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var wypozyczenie = await _context.Wypozyczenia
                .Include(w => w.Klient)
                .Include(w => w.Samochod)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (wypozyczenie == null)
            {
                return NotFound();
            }
            return View(wypozyczenie);
        }

        // POST: Wypozyczenie/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var wypozyczenie = await _context.Wypozyczenia.FindAsync(id);
            if (wypozyczenie != null)
            {
                _context.Wypozyczenia.Remove(wypozyczenie);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
