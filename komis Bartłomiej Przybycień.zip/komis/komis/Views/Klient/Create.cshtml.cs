using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace komis.Views.Klient
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
